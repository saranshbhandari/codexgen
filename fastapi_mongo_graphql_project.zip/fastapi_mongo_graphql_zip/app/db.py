from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import AsyncIterator

from fastapi import FastAPI
from pymongo import AsyncMongoClient
from pymongo.asynchronous.collection import AsyncCollection
from pymongo.asynchronous.database import AsyncDatabase

from app.config import get_settings

logger = logging.getLogger(__name__)


class MongoManager:
    def __init__(self) -> None:
        self.client: AsyncMongoClient | None = None
        self.database: AsyncDatabase | None = None
        self.collection: AsyncCollection | None = None

    async def connect(self) -> None:
        settings = get_settings()
        self.client = AsyncMongoClient(settings.mongo_uri)
        self.database = self.client[settings.mongo_db_name]
        self.collection = self.database[settings.mongo_collection_name]
        await self.client.admin.command("ping")
        logger.info("MongoDB connected")

    async def disconnect(self) -> None:
        if self.client is not None:
            await self.client.close()
            logger.info("MongoDB disconnected")


mongo_manager = MongoManager()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    await mongo_manager.connect()
    app.state.mongo_manager = mongo_manager
    yield
    await mongo_manager.disconnect()


def get_collection() -> AsyncCollection:
    if mongo_manager.collection is None:
        raise RuntimeError("MongoDB collection is not initialized")
    return mongo_manager.collection
