from __future__ import annotations

import logging
import logging.config
from typing import Any

from pythonjsonlogger import jsonlogger

from app.config import get_settings


class CustomJsonFormatter(jsonlogger.JsonFormatter):
    def add_fields(self, log_record: dict[str, Any], record: logging.LogRecord, message_dict: dict[str, Any]) -> None:
        super().add_fields(log_record, record, message_dict)
        log_record.setdefault("level", record.levelname)
        log_record.setdefault("logger", record.name)
        log_record.setdefault("module", record.module)


def configure_logging() -> None:
    settings = get_settings()

    logging_config = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "json": {
                "()": "app.logging_config.CustomJsonFormatter",
                "fmt": "%(asctime)s %(levelname)s %(name)s %(message)s %(correlation_id)s %(path)s %(method)s %(status_code)s",
            },
            "plain": {
                "format": "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
            },
        },
        "handlers": {
            "default": {
                "class": "logging.StreamHandler",
                "formatter": "json" if settings.app_env.lower() != "dev" else "plain",
            }
        },
        "root": {
            "handlers": ["default"],
            "level": settings.log_level.upper(),
        },
    }

    logging.config.dictConfig(logging_config)
