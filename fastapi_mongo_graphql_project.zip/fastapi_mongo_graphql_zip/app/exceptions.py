class AppError(Exception):
    def __init__(self, message: str, status_code: int = 400, code: str = "APP_ERROR") -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.code = code


class InvalidDocumentIdError(AppError):
    def __init__(self, document_id: str) -> None:
        super().__init__(
            message=f"Invalid MongoDB ObjectId: {document_id}",
            status_code=400,
            code="INVALID_DOCUMENT_ID",
        )


class DocumentNotFoundError(AppError):
    def __init__(self, document_id: str) -> None:
        super().__init__(
            message=f"Document not found for id: {document_id}",
            status_code=404,
            code="DOCUMENT_NOT_FOUND",
        )


class ConfigurationError(AppError):
    def __init__(self, message: str) -> None:
        super().__init__(message=message, status_code=500, code="CONFIGURATION_ERROR")
