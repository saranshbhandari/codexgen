from __future__ import annotations

from fastapi import FastAPI
from strawberry.fastapi import GraphQLRouter

from app.config import get_settings
from app.db import lifespan
from app.exceptions import AppError
from app.graphql_schema import schema
from app.logging_config import configure_logging
from app.middleware import (
    CorrelationIdMiddleware,
    RequestLoggingMiddleware,
    app_error_handler,
    generic_exception_handler,
)
from app.routes import router

configure_logging()
settings = get_settings()

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
)

app.add_middleware(CorrelationIdMiddleware)
app.add_middleware(RequestLoggingMiddleware)
app.add_exception_handler(AppError, app_error_handler)
app.add_exception_handler(Exception, generic_exception_handler)
app.include_router(router)
app.include_router(GraphQLRouter(schema), prefix="/graphql")
