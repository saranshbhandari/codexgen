from __future__ import annotations

import csv
import io
import logging
from collections import defaultdict
from typing import Any

from app.config import get_yaml_config
from app.db import get_collection
from app.exceptions import ConfigurationError, DocumentNotFoundError
from app.utils import build_projection, mongo_serialize, to_object_id

logger = logging.getLogger(__name__)


class DocumentService:
    @staticmethod
    async def get_full_document(document_id: str) -> dict[str, Any]:
        collection = get_collection()
        obj_id = to_object_id(document_id)
        document = await collection.find_one({"_id": obj_id})
        if not document:
            raise DocumentNotFoundError(document_id)
        return mongo_serialize(document)

    @staticmethod
    async def get_projected_document(document_id: str, fields: list[str]) -> dict[str, Any]:
        collection = get_collection()
        obj_id = to_object_id(document_id)
        projection = build_projection(fields)
        logger.info("fetching projected document", extra={"document_id": document_id, "projection": projection})
        document = await collection.find_one({"_id": obj_id}, projection)
        if not document:
            raise DocumentNotFoundError(document_id)
        return mongo_serialize(document)

    @staticmethod
    def _extract_simple_path(data: dict[str, Any], path: str) -> Any:
        current: Any = data
        for part in path.split("."):
            if not isinstance(current, dict):
                return None
            current = current.get(part)
            if current is None:
                return None
        return current

    @staticmethod
    def _extract_array_path(data: dict[str, Any], path: str) -> list[Any]:
        parts = path.split(".")
        array_index = None
        for i, part in enumerate(parts):
            if part.endswith("[]"):
                array_index = i
                break

        if array_index is None:
            return [DocumentService._extract_simple_path(data, path)]

        prefix_parts = parts[:array_index]
        array_field = parts[array_index][:-2]
        suffix_parts = parts[array_index + 1 :]

        current: Any = data
        for part in prefix_parts:
            if not isinstance(current, dict):
                return []
            current = current.get(part)
            if current is None:
                return []

        if not isinstance(current, dict):
            return []

        array_value = current.get(array_field)
        if not isinstance(array_value, list):
            return []

        values: list[Any] = []
        for item in array_value:
            current_item: Any = item
            for suffix in suffix_parts:
                if not isinstance(current_item, dict):
                    current_item = None
                    break
                current_item = current_item.get(suffix)
                if current_item is None:
                    break
            values.append(current_item)

        return values

    @staticmethod
    def get_requested_fields(document: dict[str, Any], fields: list[str]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for field in fields:
            if "[]" in field:
                result[field] = DocumentService._extract_array_path(document, field)
            else:
                result[field] = DocumentService._extract_simple_path(document, field)
        return result

    @staticmethod
    def build_csv_from_requested_fields(document: dict[str, Any], fields: list[str]) -> str:
        scalar_fields: dict[str, Any] = {}
        array_groups: dict[str, dict[str, list[Any]]] = defaultdict(dict)
        array_sizes: dict[str, int] = {}

        for field in fields:
            if "[]" not in field:
                scalar_fields[field] = DocumentService._extract_simple_path(document, field)
                continue

            root = field.split("[]", 1)[0] + "[]"
            values = DocumentService._extract_array_path(document, field)
            array_groups[root][field] = values
            array_sizes[root] = max(array_sizes.get(root, 0), len(values))

        total_rows = max(array_sizes.values(), default=1)
        rows: list[dict[str, Any]] = []
        for idx in range(total_rows):
            row = dict(scalar_fields)
            for _, field_map in array_groups.items():
                for field_name, values in field_map.items():
                    row[field_name] = values[idx] if idx < len(values) else None
            rows.append(row)

        output = io.StringIO()
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        return output.getvalue()

    @staticmethod
    async def flatten_configured_fields(document_id: str) -> dict[str, Any]:
        yaml_config = get_yaml_config()
        flatten_config = yaml_config.get("flatten", {})
        fields = flatten_config.get("fields", [])
        target_field = flatten_config.get("target_field", "field_flattened")

        if not fields:
            raise ConfigurationError("No flatten.fields configured in config.yaml")

        projected_document = await DocumentService.get_projected_document(document_id, fields)
        csv_text = DocumentService.build_csv_from_requested_fields(projected_document, fields)

        collection = get_collection()
        obj_id = to_object_id(document_id)
        update_result = await collection.update_one(
            {"_id": obj_id},
            {"$set": {target_field: csv_text}},
        )

        logger.info(
            "flattened document stored",
            extra={
                "document_id": document_id,
                "target_field": target_field,
                "matched_count": update_result.matched_count,
                "modified_count": update_result.modified_count,
            },
        )

        return {
            "document_id": document_id,
            "flattened_csv": csv_text,
            "target_field": target_field,
            "matched_count": update_result.matched_count,
            "modified_count": update_result.modified_count,
        }
