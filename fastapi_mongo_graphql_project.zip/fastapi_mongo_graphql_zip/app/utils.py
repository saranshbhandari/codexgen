from __future__ import annotations

from typing import Any

from bson import ObjectId
from bson.errors import InvalidId

from app.exceptions import InvalidDocumentIdError


PROJECTABLE_ARRAY_MARKER = "[]"


def to_object_id(document_id: str) -> ObjectId:
    try:
        return ObjectId(document_id)
    except (InvalidId, TypeError) as exc:
        raise InvalidDocumentIdError(document_id) from exc



def mongo_serialize(value: Any) -> Any:
    if isinstance(value, ObjectId):
        return str(value)
    if isinstance(value, list):
        return [mongo_serialize(item) for item in value]
    if isinstance(value, dict):
        return {key: mongo_serialize(val) for key, val in value.items()}
    return value



def field_to_projection_path(field: str) -> str:
    return field.replace(PROJECTABLE_ARRAY_MARKER, "")



def build_projection(fields: list[str], include_id: bool = True) -> dict[str, int]:
    projection: dict[str, int] = {}
    for field in fields:
        mongo_path = field_to_projection_path(field)
        if mongo_path:
            projection[mongo_path] = 1
    if include_id:
        projection["_id"] = 1
    return projection
