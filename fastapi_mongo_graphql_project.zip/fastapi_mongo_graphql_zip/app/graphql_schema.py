from __future__ import annotations

from typing import Optional

import strawberry
from strawberry.scalars import JSON

from app.services import DocumentService


@strawberry.type
class SelectedDocumentResponse:
    document_id: str
    data: JSON


@strawberry.type
class Query:
    @strawberry.field
    async def document_fields(self, document_id: str, fields: list[str]) -> Optional[SelectedDocumentResponse]:
        projected_document = await DocumentService.get_projected_document(document_id, fields)
        selected_fields = DocumentService.get_requested_fields(projected_document, fields)
        return SelectedDocumentResponse(document_id=document_id, data=selected_fields)

    @strawberry.field
    async def full_document(self, document_id: str) -> JSON:
        return await DocumentService.get_full_document(document_id)


schema = strawberry.Schema(query=Query)
