# FastAPI MongoDB Flatten + GraphQL API

Production-oriented FastAPI project that:

- fetches a MongoDB document by `documentId`
- flattens configured fields into CSV
- stores the CSV back in the same document under `field_flattened` (or configured target field)
- returns a complete document by `documentId`
- returns selected fields via REST and GraphQL
- optimizes reads for large documents by projecting only requested fields from MongoDB when possible
- includes structured logging, exception middleware, health endpoint, Swagger/OpenAPI, and tests

## Endpoints

- `GET /health`
- `POST /api/v1/documents/flatten`
- `GET /api/v1/documents/{document_id}`
- `POST /api/v1/documents/fields`
- `POST /graphql`
- `GET /graphql`

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Swagger UI:

- `http://127.0.0.1:8000/docs`

GraphQL UI:

- `http://127.0.0.1:8000/graphql`

## Example GraphQL query

```graphql
query {
  documentFields(
    documentId: "65f0aa11bb22cc33dd44ee55",
    fields: ["name", "profile.age", "orders[].amount"]
  ) {
    documentId
    data
  }
}
```

## Notes on projection

For selected-field reads, the service builds a MongoDB projection document from the requested field paths when those paths are projectable, such as:

- `name`
- `profile.age`
- `orders.id`
- `orders.amount`

For paths using `[]`, the service converts them internally to MongoDB dotted projection paths where safe. Some complex nested-array patterns still require application-side extraction after fetch.
