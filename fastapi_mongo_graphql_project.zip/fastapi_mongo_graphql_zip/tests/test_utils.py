from app.utils import build_projection, field_to_projection_path


def test_field_to_projection_path():
    assert field_to_projection_path("profile.age") == "profile.age"
    assert field_to_projection_path("orders[].amount") == "orders.amount"


def test_build_projection():
    projection = build_projection(["name", "orders[].amount"])
    assert projection == {"name": 1, "orders.amount": 1, "_id": 1}
