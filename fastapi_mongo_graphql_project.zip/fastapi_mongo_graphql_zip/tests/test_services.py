from app.services import DocumentService


def test_get_requested_fields():
    document = {
        "name": "John",
        "profile": {"age": 29, "city": "Pune"},
        "orders": [{"id": "A1", "amount": 100}, {"id": "A2", "amount": 200}],
    }
    result = DocumentService.get_requested_fields(document, ["name", "profile.age", "orders[].amount"])
    assert result == {
        "name": "John",
        "profile.age": 29,
        "orders[].amount": [100, 200],
    }


def test_build_csv_from_requested_fields():
    document = {
        "name": "John",
        "email": "john@example.com",
        "orders": [{"id": "A1", "amount": 100}, {"id": "A2", "amount": 200}],
    }
    csv_text = DocumentService.build_csv_from_requested_fields(
        document,
        ["name", "email", "orders[].id", "orders[].amount"],
    )
    assert "orders[].id" in csv_text
    assert "A1" in csv_text
    assert "A2" in csv_text
