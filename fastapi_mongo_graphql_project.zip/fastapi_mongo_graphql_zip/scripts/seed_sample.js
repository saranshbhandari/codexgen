use mydb;

db.mycollection.insertOne({
  name: "John",
  email: "john@example.com",
  profile: {
    age: 29,
    city: "Pune"
  },
  orders: [
    { id: "ORD-1", amount: 100 },
    { id: "ORD-2", amount: 250 }
  ]
});
