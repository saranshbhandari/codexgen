from __future__ import annotations

from fastapi import APIRouter

from app.models import FlattenRequest, FlattenResponse, FullDocumentResponse, PartialDocumentResponse
from app.services import DocumentService

router = APIRouter(prefix="/api/v1", tags=["documents"])


@router.get("/health", tags=["health"])
async def health() -> dict[str, str]:
    return {"status": "ok"}


@router.post(
    "/documents/flatten",
    response_model=FlattenResponse,
    summary="Flatten configured top-level document sections into CSV and store back in MongoDB",
)
async def flatten_document(payload: FlattenRequest) -> FlattenResponse:
    result = await DocumentService.flatten_configured_fields(payload.document_id)
    return FlattenResponse(**result)


@router.get(
    "/documents/{document_id}",
    response_model=FullDocumentResponse,
    summary="Get complete MongoDB document by id",
)
async def get_document(document_id: str) -> FullDocumentResponse:
    document = await DocumentService.get_full_document(document_id)
    return FullDocumentResponse(document=document)


@router.post(
    "/documents/fields",
    response_model=PartialDocumentResponse,
    summary="Get selected fields from a MongoDB document",
)
async def get_document_fields(payload: dict) -> PartialDocumentResponse:
    document_id = payload.get("document_id")
    fields = payload.get("fields") or []
    projected_document = await DocumentService.get_projected_document(document_id, fields)
    selected_fields = DocumentService.get_requested_fields(projected_document, fields)
    return PartialDocumentResponse(document_id=document_id, fields=selected_fields)
