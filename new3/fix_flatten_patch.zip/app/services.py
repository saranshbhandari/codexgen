from __future__ import annotations

import csv
import io
import json
import logging
from typing import Any

from app.config import get_yaml_config
from app.db import get_collection
from app.exceptions import ConfigurationError, DocumentNotFoundError
from app.utils import build_projection, mongo_serialize, to_object_id

logger = logging.getLogger(__name__)


class DocumentService:
    @staticmethod
    async def get_full_document(document_id: str) -> dict[str, Any]:
        collection = get_collection()
        obj_id = to_object_id(document_id)
        document = await collection.find_one({"_id": obj_id})
        if not document:
            raise DocumentNotFoundError(document_id)
        return mongo_serialize(document)

    @staticmethod
    async def get_projected_document(document_id: str, fields: list[str]) -> dict[str, Any]:
        collection = get_collection()
        obj_id = to_object_id(document_id)
        projection = build_projection(fields)
        logger.info("fetching projected document", extra={"document_id": document_id, "projection": projection})
        document = await collection.find_one({"_id": obj_id}, projection)
        if not document:
            raise DocumentNotFoundError(document_id)
        return mongo_serialize(document)

    @staticmethod
    def _extract_simple_path(data: dict[str, Any], path: str) -> Any:
        current: Any = data
        for part in path.split("."):
            if not isinstance(current, dict):
                return None
            current = current.get(part)
            if current is None:
                return None
        return current

    @staticmethod
    def _extract_array_path(data: dict[str, Any], path: str) -> list[Any]:
        parts = path.split(".")
        array_index = None
        for i, part in enumerate(parts):
            if part.endswith("[]"):
                array_index = i
                break

        if array_index is None:
            return [DocumentService._extract_simple_path(data, path)]

        prefix_parts = parts[:array_index]
        array_field = parts[array_index][:-2]
        suffix_parts = parts[array_index + 1 :]

        current: Any = data
        for part in prefix_parts:
            if not isinstance(current, dict):
                return []
            current = current.get(part)
            if current is None:
                return []

        if not isinstance(current, dict):
            return []

        array_value = current.get(array_field)
        if not isinstance(array_value, list):
            return []

        values: list[Any] = []
        for item in array_value:
            current_item: Any = item
            for suffix in suffix_parts:
                if not isinstance(current_item, dict):
                    current_item = None
                    break
                current_item = current_item.get(suffix)
                if current_item is None:
                    break
            values.append(current_item)

        return values

    @staticmethod
    def get_requested_fields(document: dict[str, Any], fields: list[str]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for field in fields:
            if "[]" in field:
                result[field] = DocumentService._extract_array_path(document, field)
            else:
                result[field] = DocumentService._extract_simple_path(document, field)
        return result

    @staticmethod
    def _flatten_object(value: Any, parent_key: str = "", sep: str = ".") -> dict[str, Any]:
        flat: dict[str, Any] = {}

        if isinstance(value, dict):
            for key, child in value.items():
                new_key = f"{parent_key}{sep}{key}" if parent_key else key
                flat.update(DocumentService._flatten_object(child, new_key, sep))
            return flat

        if isinstance(value, list):
            # list[dict] / list[list] are kept as JSON strings at leaf level
            flat[parent_key or "value"] = json.dumps(value, ensure_ascii=False)
            return flat

        flat[parent_key or "value"] = value
        return flat

    @staticmethod
    def _normalize_cell(value: Any) -> Any:
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        return value

    @staticmethod
    def _section_to_csv(section: Any) -> str:
        output = io.StringIO(newline="")

        if isinstance(section, dict):
            row = DocumentService._flatten_object(section)
            fieldnames = list(row.keys()) or ["value"]
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow({key: DocumentService._normalize_cell(val) for key, val in row.items()})
            return output.getvalue()

        if isinstance(section, list):
            if not section:
                writer = csv.DictWriter(output, fieldnames=["value"])
                writer.writeheader()
                return output.getvalue()

            if all(isinstance(item, dict) for item in section):
                rows = [DocumentService._flatten_object(item) for item in section]
                fieldnames: list[str] = []
                seen: set[str] = set()
                for row in rows:
                    for key in row.keys():
                        if key not in seen:
                            seen.add(key)
                            fieldnames.append(key)

                if not fieldnames:
                    fieldnames = ["value"]

                writer = csv.DictWriter(output, fieldnames=fieldnames)
                writer.writeheader()
                for row in rows:
                    normalized_row = {key: DocumentService._normalize_cell(val) for key, val in row.items()}
                    writer.writerow(normalized_row)
                return output.getvalue()

            writer = csv.DictWriter(output, fieldnames=["value"])
            writer.writeheader()
            for item in section:
                writer.writerow({"value": DocumentService._normalize_cell(item)})
            return output.getvalue()

        writer = csv.DictWriter(output, fieldnames=["value"])
        writer.writeheader()
        writer.writerow({"value": DocumentService._normalize_cell(section)})
        return output.getvalue()

    @staticmethod
    async def flatten_configured_fields(document_id: str) -> dict[str, Any]:
        yaml_config = get_yaml_config()
        flatten_config = yaml_config.get("flatten", {})
        fields = flatten_config.get("fields", [])

        if not fields:
            raise ConfigurationError("No flatten.fields configured in config.yaml")

        collection = get_collection()
        obj_id = to_object_id(document_id)

        projection = build_projection(fields)
        logger.info(
            "fetching configured sections for flattening",
            extra={"document_id": document_id, "projection": projection},
        )

        document = await collection.find_one({"_id": obj_id}, projection)
        if not document:
            raise DocumentNotFoundError(document_id)

        document = mongo_serialize(document)

        flattened_fields: dict[str, str] = {}
        for field in fields:
            section_value = document.get(field)
            if section_value is None:
                logger.info(
                    "configured field missing in document, skipping",
                    extra={"document_id": document_id, "field_name": field},
                )
                continue

            flattened_fields[f"{field}_flattened"] = DocumentService._section_to_csv(section_value)

        update_doc = {"$set": flattened_fields} if flattened_fields else {"$set": {}}
        update_result = await collection.update_one({"_id": obj_id}, update_doc)

        logger.info(
            "flattened sections stored",
            extra={
                "document_id": document_id,
                "matched_count": update_result.matched_count,
                "modified_count": update_result.modified_count,
                "flattened_field_names": list(flattened_fields.keys()),
            },
        )

        return {
            "document_id": document_id,
            "flattened_fields": flattened_fields,
            "matched_count": update_result.matched_count,
            "modified_count": update_result.modified_count,
        }
