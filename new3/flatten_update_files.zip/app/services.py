
from __future__ import annotations

import csv
import io
from typing import Any
import logging

logger = logging.getLogger(__name__)

class DocumentService:

    @staticmethod
    def _flatten_dict(data: dict[str, Any], parent_key: str = "", sep: str = ".") -> dict[str, Any]:
        items: dict[str, Any] = {}
        for key, value in data.items():
            new_key = f"{parent_key}{sep}{key}" if parent_key else key
            if isinstance(value, dict):
                items.update(DocumentService._flatten_dict(value, new_key, sep))
            else:
                items[new_key] = value
        return items

    @staticmethod
    def _section_to_csv(section: Any) -> str:
        output = io.StringIO()

        if isinstance(section, dict):
            flattened = DocumentService._flatten_dict(section)
            writer = csv.DictWriter(output, fieldnames=list(flattened.keys()))
            writer.writeheader()
            writer.writerow(flattened)
            return output.getvalue()

        if isinstance(section, list):
            if all(isinstance(item, dict) for item in section):
                flattened_rows = [DocumentService._flatten_dict(item) for item in section]

                fieldnames = []
                seen = set()

                for row in flattened_rows:
                    for key in row.keys():
                        if key not in seen:
                            seen.add(key)
                            fieldnames.append(key)

                writer = csv.DictWriter(output, fieldnames=fieldnames)
                writer.writeheader()

                for row in flattened_rows:
                    writer.writerow(row)

                return output.getvalue()

            writer = csv.DictWriter(output, fieldnames=["value"])
            writer.writeheader()

            for item in section:
                writer.writerow({"value": item})

            return output.getvalue()

        writer = csv.DictWriter(output, fieldnames=["value"])
        writer.writeheader()
        writer.writerow({"value": section})
        return output.getvalue()
