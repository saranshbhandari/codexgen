
from __future__ import annotations

import logging
import logging.config
from typing import Any

class SimpleFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        record.correlation_id = getattr(record, "correlation_id", "-")
        record.path = getattr(record, "path", "-")
        record.method = getattr(record, "method", "-")
        record.status_code = getattr(record, "status_code", "-")
        record.duration_ms = getattr(record, "duration_ms", "-")
        record.document_id = getattr(record, "document_id", "-")
        return super().format(record)


def configure_logging() -> None:

    logging_config: dict[str, Any] = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "plain": {
                "()": "app.logging_config.SimpleFormatter",
                "format": (
                    "%(asctime)s | %(levelname)s | %(name)s | %(message)s | "
                    "corr=%(correlation_id)s | doc=%(document_id)s | "
                    "%(method)s %(path)s | status=%(status_code)s | duration=%(duration_ms)s"
                ),
            }
        },
        "handlers": {
            "default": {
                "class": "logging.StreamHandler",
                "formatter": "plain",
            }
        },
        "root": {
            "handlers": ["default"],
            "level": "INFO",
        },
    }

    logging.config.dictConfig(logging_config)
