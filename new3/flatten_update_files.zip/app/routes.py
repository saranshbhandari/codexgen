
from __future__ import annotations

from fastapi import APIRouter
from app.models import FlattenRequest, FlattenResponse

router = APIRouter(prefix="/api/v1", tags=["documents"])

@router.get("/health")
async def health():
    return {"status": "ok"}

@router.post("/documents/flatten", response_model=FlattenResponse)
async def flatten_document(payload: FlattenRequest):
    # This endpoint should call DocumentService.flatten_configured_fields
    # once integrated with MongoDB layer in your project.
    return FlattenResponse(
        document_id=payload.document_id,
        flattened_fields={},
        matched_count=1,
        modified_count=1,
    )
