
from __future__ import annotations
from typing import Any
from pydantic import BaseModel, Field

class FlattenRequest(BaseModel):
    document_id: str = Field(..., description="MongoDB ObjectId as string")

class FlattenResponse(BaseModel):
    document_id: str
    flattened_fields: dict[str, str]
    matched_count: int
    modified_count: int

class PartialDocumentResponse(BaseModel):
    document_id: str
    fields: dict[str, Any]

class FullDocumentResponse(BaseModel):
    document: dict[str, Any]
